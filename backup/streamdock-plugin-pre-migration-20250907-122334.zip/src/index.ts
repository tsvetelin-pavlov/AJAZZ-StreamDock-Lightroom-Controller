/*
 StreamDock plugin entry: exposes an HTTP poll server for Lightroom to fetch commands.
*/

import http from 'node:http';

export type Command = {
  type: 'delta' | 'set' | 'invoke';
  target: string;
  value?: number;
};

const HOST = '127.0.0.1';
const PORT = 58762; // Must match Lightroom Core.lua pollUrl/ackUrl

const queue: string[] = [];

function enqueue(cmd: Command) {
  // Lightroom expects a Lua table literal, not JSON
  const parts: string[] = ["{ type = '", cmd.type, "', target = '", cmd.target, "'"];
  if (typeof cmd.value === 'number') parts.push(', value = ', String(cmd.value));
  parts.push(' }');
  queue.push(parts.join(''));
}

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/poll') {
    const item = queue.shift();
    if (item) {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end(item);
    } else {
      res.writeHead(204);
      res.end();
    }
    return;
  }
  if (req.method === 'POST' && req.url === '/ack') {
    req.on('data', () => { });
    req.on('end', () => { res.writeHead(200); res.end('ok'); });
    return;
  }
  res.writeHead(404); res.end('not found');
});

server.listen(PORT, HOST, () => {
  console.log(`StreamDock Lightroom queue listening at http://${HOST}:${PORT}`);
});

// API expected by StreamDock runtime
export function onKnobRotate(paramId: string, ticks: number) {
  const delta = ticks * 0.01;
  enqueue({ type: 'delta', target: paramId, value: delta });
}

export function onButtonPress(actionId: string) {
  enqueue({ type: 'invoke', target: actionId });
}

export function onSliderSet(paramId: string, value01: number) {
  enqueue({ type: 'set', target: paramId, value: value01 });
}
