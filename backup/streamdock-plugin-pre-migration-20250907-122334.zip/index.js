// Simple HTTP long-poll queue for Lightroom plugin to poll commands
// And exported shims StreamDock could call: onKnobRotate, onButtonPress, onSliderSet

const http = require('http');

const PORT = 58762;
let pending = [];
let waitingRes = null;

function enqueue(cmd) {
  const payload = `{ type='${cmd.type}', target='${cmd.target}'${cmd.value !== undefined ? ", value=" + cmd.value : ''} }`;
  if (waitingRes) {
    waitingRes.writeHead(200, { 'Content-Type': 'text/plain' });
    waitingRes.end(payload);
    waitingRes = null;
  } else {
    pending.push(payload);
  }
}

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url.startsWith('/poll')) {
    if (pending.length > 0) {
      const next = pending.shift();
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end(next);
    } else {
      // hold connection up to 20s
      waitingRes = res;
      req.on('close', () => {
        if (waitingRes === res) waitingRes = null;
      });
      // safety timeout
      setTimeout(() => {
        if (waitingRes === res) {
          res.writeHead(204);
          res.end();
          waitingRes = null;
        }
      }, 20000);
    }
    return;
  }
  if (req.method === 'GET' && req.url.startsWith('/enqueue')) {
    const u = new URL(req.url, 'http://localhost');
    const type = u.searchParams.get('type');
    const target = u.searchParams.get('target');
    const value = u.searchParams.get('value');
    if (!type || !target) {
      res.writeHead(400);
      res.end('missing type or target');
      return;
    }
    const cmd = { type, target };
    if (value !== null && value !== undefined) cmd.value = Number(value);
    enqueue(cmd);
    res.writeHead(200);
    res.end('queued');
    return;
  }
  if (req.method === 'POST' && req.url.startsWith('/ack')) {
    // acknowledge
    res.writeHead(200);
    res.end('ok');
    return;
  }
  res.writeHead(404);
  res.end('not found');
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`StreamDock Lightroom queue listening on 127.0.0.1:${PORT}`);
});

// API for StreamDock runtime
function onKnobRotate(paramId, ticks) {
  const delta = ticks * 0.01;
  enqueue({ type: 'delta', target: paramId, value: delta });
}

function onButtonPress(actionId) {
  enqueue({ type: 'invoke', target: actionId });
}

function onSliderSet(paramId, value01) {
  enqueue({ type: 'set', target: paramId, value: value01 });
}

module.exports = { onKnobRotate, onButtonPress, onSliderSet };
